package com.farzain.watchmovie.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.farzain.watchmovie.R;
import com.farzain.watchmovie.Series;

public class SeriesInfoActivity extends AppCompatActivity {

    public static final String EXTRA_SERIES = "extra_series";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_series_info);

        TextView movieRelease = findViewById(R.id.content_release);
        TextView movieName = findViewById(R.id.content_name);
        TextView movieSynopsis = findViewById(R.id.content_sinopsis);
        ImageView moviePoster = findViewById(R.id.moviePoster);

        ProgressBar progressBar = findViewById(R.id.progressBarSeries);
        progressBar.setVisibility(View.VISIBLE);

        Series dataSeries = getIntent().getParcelableExtra(EXTRA_SERIES);
        String url_image = "https://image.tmdb.org/t/p/w185" + dataSeries.getPhoto();

        Series dataMovie = getIntent().getParcelableExtra(EXTRA_SERIES);
        movieName.setText(dataMovie.getName());
        movieSynopsis.setText(dataMovie.getSynopsis());
        movieRelease.setText(dataMovie.getRelease());
        Glide.with(this)
                .load(url_image)
                .apply(new RequestOptions().override(350, 550))
                .into(moviePoster);
        progressBar.setVisibility(View.GONE);
    }
}
