package com.farzain.watchmovie.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.farzain.watchmovie.Movie;
import com.farzain.watchmovie.R;

public class MovieInfoActivity extends AppCompatActivity {

    public static final String EXTRA_MOVIE = "extra_movie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_info);

        TextView movieRelease = findViewById(R.id.content_release);
        TextView movieName = findViewById(R.id.content_name);
        TextView movieSynopsis = findViewById(R.id.content_sinopsis);
        ImageView moviePoster = findViewById(R.id.moviePoster);

        ProgressBar progressBar = findViewById(R.id.progressBarInfo);
        progressBar.setVisibility(View.VISIBLE);

        Movie dataMovie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        String url_image = "https://image.tmdb.org/t/p/w185" + dataMovie.getPhoto();

        movieName.setText(dataMovie.getName());
        movieSynopsis.setText(dataMovie.getSynopsis());
        movieRelease.setText(dataMovie.getRelease());
        Glide.with(MovieInfoActivity.this)
                .load(url_image)
                .placeholder(R.color.colorAccent)
                .dontAnimate()
                .into(moviePoster);
        progressBar.setVisibility(View.GONE);
    }
}
