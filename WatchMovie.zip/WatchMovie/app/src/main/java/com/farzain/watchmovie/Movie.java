package com.farzain.watchmovie;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONObject;

public class Movie implements Parcelable {
    private String name;
    private String synopsis;
    private String photo;
    private String banner;
    private String release;

    protected Movie(Parcel in) {
        name = in.readString();
        synopsis = in.readString();
        photo = in.readString();
        release = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public Movie(JSONObject jsonObject) {
        try {
            String title = jsonObject.getString("title");
            String overview = jsonObject.getString("overview");
            String release_date = jsonObject.getString("release_date");
            String poster_path = jsonObject.getString("poster_path");
            String backdrop_path = jsonObject.getString("backdrop_path");

            this.name = title;
            this.synopsis = overview;
            this.release = release_date;
            this.photo = poster_path;
            this.banner = backdrop_path;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(synopsis);
        dest.writeString(photo);
        dest.writeString(release);
    }
}
